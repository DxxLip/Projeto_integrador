const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const loginBtn = document.getElementById('login');
const loginEmail = document.getElementById('loginEmail');
const loginPassword = document.getElementById('loginPassword');

registerBtn.addEventListener('click', () => {
  container.classList.add('active');
});

loginBtn.addEventListener('click', () => {
  container.classList.remove('active');
});

function salvarUsuario(nome, email, senha) {
  const usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];
  usuarios.push({ nome, email, senha });
  localStorage.setItem('usuarios', JSON.stringify(usuarios));
}

(function criarAdmin() {
  const usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];
  if (!usuarios.some(user => user.email === 'admin@admin.com')) {
    usuarios.push({ nome: 'Admin', email: 'admin@admin.com', senha: 'admin123' });
    localStorage.setItem('usuarios', JSON.stringify(usuarios));
  }
})();

function exibirMensagem(input, mensagem, tipo = 'erro') {
  const mensagemExistente = input.parentElement.querySelector('.tooltip');
  if (mensagemExistente) mensagemExistente.remove();

  const tooltip = document.createElement('div');
  tooltip.classList.add('tooltip', tipo);
  tooltip.innerText = mensagem;
  input.parentElement.style.position = 'relative';
  input.parentElement.appendChild(tooltip);

  setTimeout(() => tooltip.remove(), 3000);
}

document.getElementById('registerForm').addEventListener('submit', (event) => {
  event.preventDefault();
  const nome = document.getElementById('name').value;
  const email = document.getElementById('email').value;
  const senha = document.getElementById('password').value;
  const confirmarSenha = document.getElementById('confirmPassword').value;

  if (senha !== confirmarSenha) {
    exibirMensagem(document.getElementById('confirmPassword'), 'As senhas não coincidem!');
    return;
  }

  salvarUsuario(nome, email, senha);
  loginEmail.value = email;
  loginPassword.value = senha;
  alert('Usuário cadastrado com sucesso!');
  container.classList.remove('active');
});

document.getElementById('loginForm').addEventListener('submit', (event) => {
  event.preventDefault();
  const email = loginEmail.value;
  const senha = loginPassword.value;
  const usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];

  const usuario = usuarios.find(user => user.email === email && user.senha === senha);
  if (usuario) {
    if (usuario.email === 'admin@admin.com') {
      alert(`Bem-vindo, ${usuario.nome}! Redirecionando para a página do administrador.`);
      window.location.href = "admin.html"; // Redireciona para a página do administrador
    } else {
      alert(`Bem-vindo, ${usuario.nome}!`);
      window.location.href = "testimonial.html"; // Redireciona para a página padrão
    }
  } else {
    exibirMensagem(loginEmail, 'Email ou senha inválidos!');
  }
});
